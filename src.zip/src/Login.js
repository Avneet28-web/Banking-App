import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    // Hardcoded credentials for validation
    const validUsername = 'avneet128@gmail.com';
    const validPassword = 'abc001234';

    if (username === validUsername && password === validPassword) {
      setMessage('Login Successful');
      setTimeout(() => {
        navigate('/transaction');
      }, 2000); // Redirect after 2 seconds to show the message
    } else {
      setMessage('Invalid username or password');
    }
  };

  return (
    <div className="container mt-5">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group mb-3">
          <label htmlFor="username">Username</label>
          <input
            type="email"
            className="form-control"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="form-group mb-3">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            className="form-control"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-danger">Login</button>
      </form>
      {message && <div className="mt-3 alert alert-info" role="alert">{message}</div>}
    </div>
  );
};

export default Login;
