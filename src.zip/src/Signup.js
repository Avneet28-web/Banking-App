import React from 'react';

const Signup = () => {
  return <h2>Signup Page</h2>;
};

export default Signup;