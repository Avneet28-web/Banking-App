// About.js
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const About = () => {
  return (
    <div className="container mt-3">
      <h2>About Us</h2>
      <p>Welcome to our banking app! We provide a range of services to help you manage your finances with ease and convenience.</p>
      
      <h3>Features</h3>
      <ul>
        <li>Deposit and Withdraw Funds</li>
        <li>E-Transfer between accounts</li>
        <li>View your transaction history</li>
        <li>Check your account balance in real-time</li>
      </ul>

      <h3>Our Mission</h3>
      <p>Our mission is to deliver secure and efficient banking services, making financial management straightforward and accessible for everyone.</p>

      <h3>Contact Us</h3>
      <p>If you have any questions or feedback, please reach out to our support team at support@bankingapp.com.</p>
    </div>
  );
};

export default About;
