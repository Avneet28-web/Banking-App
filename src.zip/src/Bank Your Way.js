import React from 'react';

const BankYourWay = () => {
  return (
    <div className="bank-your-way">
      <h4>Bank Your Way</h4>
      <p>Experience banking that fits your lifestyle with our flexible solutions.</p>
    </div>
  );
};

export default BankYourWay;
