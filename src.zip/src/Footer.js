// Footer.js
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'; 

const Footer = () => {
  return (
    <footer className="footer bg-light text-center py-3">
      <div className="container">
        <p className="mb-0">© {new Date().getFullYear()} Banking App. All rights reserved.</p>
        <p className="mb-0">Designed and developed in Canada.</p>
        <p>
          <a href="mailto:support@bankingapp.com">Contact Us</a>
        </p>
      </div>
    </footer>
  );
};

export default Footer;
