// src/Location.js
import React from 'react';

function Location() {
  return (
    <div className="footer-item">
      <h5>Location</h5>
      <p>123 Main Street</p>
      <p>Cityville, ST 12345</p>
    </div>
  );
}

export default Location;
