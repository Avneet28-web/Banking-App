import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css'; 
import lefthero from './lefthero.jpg'; 
const Home = () => {
  return (
    <div className="container mt-3">
      <div className="hero-container mb-4">
        <div className="hero-image">
          <img src={lefthero} alt="Hero" className="img-fluid" />
        </div>
        <div className="hero-text">
          <h1>Welcome to Scotiabank</h1>
          <p>Providing you with the best financial solutions</p>
        </div>
      </div>
      <h2>Our Services</h2>
      <div className="row">
        <div className="col-md-3 mb-3">
          <div className="service-card">
            <h4>Financial Services</h4>
            <p>Explore our range of financial services tailored to your needs.</p>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="service-card">
            <h4>Credit Cards</h4>
            <p>Find the right credit card for your spending needs.</p>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="service-card">
            <h4>Other Services</h4>
            <p>Discover other services we offer to make banking easier.</p>
          </div>
        </div>
        <div className="col-md-3 mb-3">
          <div className="service-card">
            <h4>Contact Us</h4>
            <p>Get in touch with us for any queries or support.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
