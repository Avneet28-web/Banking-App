import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import { BrowserRouter as Router, Route, Routes, Link, useNavigate } from 'react-router-dom';
import Home from './Home';
import About from './About';
import Location from './Location';
import banklogo from './logo.jpg';


const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    // Hardcoded credentials for validation
    const validUsername = 'avneet128@gmail.com';
    const validPassword = 'abc001234';

    if (username === validUsername && password === validPassword) {
      setMessage('Login Successful');
      setTimeout(() => {
        navigate('/transaction');
      }, 2000); // Redirect after 2 seconds to show the message
    } else {
      setMessage('Invalid username or password');
    }
  };

  return (
    <div className="container mt-5">
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group mb-3">
          <label htmlFor="username">Username</label>
          <input
            type="email"
            className="form-control"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="form-group mb-3">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            className="form-control"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-danger">Login</button>
      </form>
      {message && <div className="mt-3 alert alert-info" role="alert">{message}</div>}
    </div>
  );
};

const Deposit = ({ onDeposit }) => {
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onDeposit({ accountNumber, amount });
    setAccountNumber('');
    setAmount('');
  };

  const handleCancel = () => {
    setAccountNumber('');
    setAmount('');
  };

  return (
    <div className="mb-4">
      <h3>Deposit</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="accountNumber">Account Number</label>
          <input
            type="text"
            className="form-control"
            id="accountNumber"
            value={accountNumber}
            onChange={(e) => setAccountNumber(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="amount">Amount</label>
          <input
            type="number"
            className="form-control"
            id="amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </div>


        <button type="submit" className="btn btn-danger me-3">Deposit</button>


        <button type="button" className="btn btn-secondary" onClick={handleCancel}>Cancel</button>
      </form>
    </div>
  );
};


const Withdraw = ({ onWithdraw }) => {
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onWithdraw({ accountNumber, amount });
    setAccountNumber('');
    setAmount('');
  };

  const handleCancel = () => {
    setAccountNumber('');
    setAmount('');
  };

  return (
    <div className="mb-4">
      <h3>Withdraw</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="accountNumber">Account Number</label>
          <input
            type="text"
            className="form-control"
            id="accountNumber"
            value={accountNumber}
            onChange={(e) => setAccountNumber(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="amount">Amount</label>
          <input
            type="number"
            className="form-control"
            id="amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </div>


        <button type="submit" className="btn btn-danger me-3">Withdraw</button>


        <button type="button" className="btn btn-secondary" onClick={handleCancel}>Cancel</button>
      </form>
    </div>
  );
};


const ETransfer = ({ onTransfer }) => {
  const [fromAccount, setFromAccount] = useState('');
  const [toAccount, setToAccount] = useState('');
  const [amount, setAmount] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onTransfer({ fromAccount, toAccount, amount });
    setFromAccount('');
    setToAccount('');
    setAmount('');
  };

  const handleCancel = () => {
    setFromAccount('');
    setToAccount('');
    setAmount('');
  };

  return (
    <div className="mb-4">
      <h3>E-Transfer</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="fromAccount">From Account</label>
          <input
            type="text"
            className="form-control"
            id="fromAccount"
            value={fromAccount}
            onChange={(e) => setFromAccount(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="toAccount">To Account</label>
          <input
            type="text"
            className="form-control"
            id="toAccount"
            value={toAccount}
            onChange={(e) => setToAccount(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="amount">Amount</label>
          <input
            type="number"
            className="form-control"
            id="amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </div>


        <button type="submit" className="btn btn-danger me-3">Transfer</button>


        <button type="button" className="btn btn-secondary" onClick={handleCancel}>Cancel</button>
      </form>
    </div>
  );
};


const Transaction = ({ balance, transactions }) => {
  return (
    <div className="container">
      <h2> Transactions </h2>
      <p></p>
      <p><strong>Current Balance:</strong> ${balance}</p>
      <div className="button-group mb-4">
        <Link to="/deposit" className="btn btn-danger me-3"> Deposit</Link>
        <Link to="/withdraw" className="btn btn-danger me-3"> Withdraw</Link>
        <Link to="/etransfer" className="btn btn-danger"> E-Transfer</Link>
      </div>
      <div className="mt-4">
        <h4>Transaction History</h4>
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Transaction Type</th>
              <th>Account Number</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction, index) => (
              <tr key={index}>
                <td>{transaction.type}</td>
                <td>{transaction.accountNumber}</td>
                <td>${transaction.amount}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};


const Logout = () => {
  return (
    <div className="container mt-3">
      <h2></h2>
      <p>You have been logged out. <Link to="/">Go to Home</Link></p>
    </div>
  );
};

const Footer = () => {
  return (
    <footer className="footer bg-light text-center py-3">
      <div className="container">
        <p className="mb-0">© {new Date().getFullYear()} Banking App. All rights reserved.</p>
        <p className="mb-0">Designed and developed in Canada.</p>
        <p>
          <a href="mailto:support@bankingapp.com">Contact Us</a>
        </p>
      </div>
    </footer>
  );
};

function App() {
  const [balance, setBalance] = useState(0);
  const [transactions, setTransactions] = useState([]);
  const [alertMessage, setAlertMessage] = useState('');

  const handleDeposit = ({ accountNumber, amount }) => {
    setBalance(prevBalance => prevBalance + parseFloat(amount));
    setTransactions([...transactions, { type: 'Deposit', accountNumber, amount }]);
    setAlertMessage(`Deposit successful! Account: ${accountNumber}, Amount: ${amount}`);
    setTimeout(() => setAlertMessage(''), 5000); 
  };

  const handleWithdraw = ({ accountNumber, amount }) => {
    setBalance(prevBalance => prevBalance - parseFloat(amount));
    setTransactions([...transactions, { type: 'Withdraw', accountNumber, amount }]);
    setAlertMessage(`Withdrawal successful! Account: ${accountNumber}, Amount: ${amount}`);
    setTimeout(() => setAlertMessage(''), 5000); 
  };

  const handleTransfer = ({ fromAccount, toAccount, amount }) => {
    setBalance(prevBalance => prevBalance - parseFloat(amount));
    setTransactions([...transactions, { type: 'Transfer', fromAccount, toAccount, amount }]);
    setAlertMessage(`Transfer successful! From: ${fromAccount}, To: ${toAccount}, Amount: ${amount}`);
    setTimeout(() => setAlertMessage(''), 5000); 
  };

  return (
    <div className="App">
      <Router>
        <nav className="navbar navbar-expand-lg myNav">
          <div className="container d-flex justify-content-between align-items-center">
            {/* Logo */}
            <Link className="navbar-brand" to="/">
              <img src={banklogo} alt="Bank Logo" className="bank-logo" />
            </Link>

            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>

            <div className="collapse navbar-collapse justify-content-end" id="navbarNav">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link className="nav-link" to="/">Home</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/about">About</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/location">Location</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/transaction">Transaction</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/login">Login</Link>
                </li>
                <li className="nav-item">
                  <Link className="nav-link" to="/logout">Logout</Link>
                </li>
              </ul>
            </div>
          </div>
        </nav>

        {alertMessage && <div className="alert alert-success" role="alert">{alertMessage}</div>}

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/location" element={<Location />} />
          <Route path="/transaction" element={<Transaction balance={balance} transactions={transactions} />} />
          <Route path="/deposit" element={<Deposit onDeposit={handleDeposit} />} />
          <Route path="/withdraw" element={<Withdraw onWithdraw={handleWithdraw} />} />
          <Route path="/etransfer" element={<ETransfer onTransfer={handleTransfer} />} />
          <Route path="/logout" element={<Logout />} />
          <Route path="/login" element={<Login />} />
        </Routes>

        <Footer />
      </Router>
    </div>
  );
}

export default App;
