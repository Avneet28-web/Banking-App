// Transfer.js
import React, { useState } from 'react';

const Transfer = ({ onTransfer }) => {
  const [fromAccount, setFromAccount] = useState('');
  const [toAccount, setToAccount] = useState('');
  const [amount, setAmount] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onTransfer({ fromAccount, toAccount, amount });
    setFromAccount('');
    setToAccount('');
    setAmount('');
  };

  const handleCancel = () => {
    setFromAccount('');
    setToAccount('');
    setAmount('');
  };

  return (
    <div className="mb-4">
      <h3>E-Transfer</h3>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="fromAccount">From Account Number</label>
          <input
            type="text"
            className="form-control"
            id="fromAccount"
            value={fromAccount}
            onChange={(e) => setFromAccount(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="toAccount">To Account Number</label>
          <input
            type="text"
            className="form-control"
            id="toAccount"
            value={toAccount}
            onChange={(e) => setToAccount(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="amount">Amount</label>
          <input
            type="number"
            className="form-control"
            id="amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary me-3">Transfer</button> {/* Space added */}
        <button type="button" className="btn btn-secondary" onClick={handleCancel}>Cancel</button>
      </form>
    </div>
  );
};

export default Transfer;
