// src/Transaction.js
import React from 'react';

const Transaction = () => {
  return (
    <div className="container">
      <h2></h2>
      <p></p>
    </div>
  );
};

export default Transaction;
